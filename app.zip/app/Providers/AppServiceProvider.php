<?php

namespace App\Providers;

use App\Models\Tenant;
use App\Support\Tenancy\Tenancy;
use Illuminate\Database\Eloquent\Relations\Relation;
use Illuminate\Queue\Events\JobProcessing;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->scoped(\App\Support\Tenancy\Tenancy::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        \App\Models\Product::observe(\App\Observers\ProductObserver::class);
        \App\Models\ProductVariant::observe(\App\Observers\ProductVariantObserver::class);
        \App\Models\Tenant::observe(\App\Observers\TenantObserver::class);
        \App\Models\SerialNumber::observe(\App\Observers\SerialNumberObserver::class);
        \App\Models\ProductReview::observe(\App\Observers\ProductReviewObserver::class);
        \App\Models\BlogPost::observe(\App\Observers\BlogPostObserver::class);
        \Illuminate\Pagination\Paginator::defaultView('components.ui.pagination');
        
        Relation::morphMap([
            'product' => \App\Models\Product::class,
            'category' => \App\Models\Category::class,
            'brand' => \App\Models\Brand::class,
            'collection' => \App\Models\Collection::class,
            'static_page' => \App\Models\StaticPage::class,
            'blog_post' => \App\Models\BlogPost::class,
        ]);

        \App\Models\Category::observe(\App\Observers\CategoryObserver::class);
        \App\Models\Brand::observe(\App\Observers\BrandObserver::class);
        \App\Models\Collection::observe(\App\Observers\CollectionObserver::class);
        \App\Models\StaticPage::observe(\App\Observers\StaticPageObserver::class);
        \App\Models\ProductTranslation::observe(\App\Observers\ProductTranslationObserver::class);

        Event::listen(\App\Events\OrderPlaced::class, \App\Listeners\SendOrderPlacedNotifications::class);
        Event::listen(\App\Events\OrderStatusChanged::class, \App\Listeners\SendOrderStatusChangedNotifications::class);
        Event::listen(\App\Events\OrderCancelled::class, \App\Listeners\SendOrderCancelledNotifications::class);
        Event::listen(\App\Events\OrderPaymentRecorded::class, \App\Listeners\SendPaymentRecordedNotifications::class);

        // --- Tenant Queue Boundary Preservation ---
        
        // 1. Append the tenant_id to the queued job payload
        Queue::createPayloadUsing(function () {
            $tenant = tenant();
            
            return $tenant ? ['tenant_id' => $tenant->id] : [];
        });

        // 2. Restore the tenant context right before the worker processes the job
        Queue::before(function (JobProcessing $event) {
            $payload = $event->job->payload();

            if (isset($payload['tenant_id'])) {
                // Restore tenant context
                $tenant = Tenant::withoutGlobalScope('tenant')->find($payload['tenant_id']);
                
                if ($tenant) {
                    app(Tenancy::class)->set($tenant);
                }
            }
        });
    }
}