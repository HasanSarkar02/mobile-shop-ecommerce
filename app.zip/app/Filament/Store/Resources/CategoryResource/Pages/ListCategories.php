<?php

declare(strict_types=1);

namespace App\Filament\Store\Resources\CategoryResource\Pages;

use App\Filament\Store\Resources\CategoryResource;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ListRecords;

class ListCategories extends ListRecords
{
    protected static string $resource = CategoryResource::class;

    protected function getHeaderActions(): array
    {
        return [CreateAction::make()];
    }
}