<?php

declare(strict_types=1);

namespace App\Filament\Store\Resources\CategoryResource\Pages;

use App\Filament\Store\Resources\CategoryResource;
use Filament\Actions\DeleteAction;
use Filament\Resources\Pages\EditRecord;

class EditCategory extends EditRecord
{
    protected static string $resource = CategoryResource::class;

    protected function getHeaderActions(): array
    {
        return [DeleteAction::make()];
    }
}