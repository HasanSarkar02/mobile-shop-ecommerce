<?php

declare(strict_types=1);

namespace App\Livewire;

use App\Services\CartService;
use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\On;
use Livewire\Component;

class MiniCart extends Component
{
    public function render(CartService $carts)
    {
        $cart = $carts->getOrCreateCart(Auth::guard('customer')->user(), request()->cookie('cart_token'));
        $cart->load('items.variant.product.translations');

        return view('livewire.mini-cart', [
            'itemCount' => $cart->items->sum('quantity'),
            'subtotal' => $cart->items->sum(fn ($item) => $item->lineTotal()),
            'items' => $cart->items,
        ]);
    }

    #[On('cart-updated')]
    public function refresh(): void
    {
        // render() re-runs automatically; method exists purely to register the listener.
    }
}