<?php

declare(strict_types=1);

namespace App\Services\Storefront;

use App\Models\Collection;
use App\Models\HomepageSection;
use App\Models\Product;
use Illuminate\Support\Collection as EloquentCollection;

class HomepageSectionRenderer
{
    public function __construct(private readonly ProductListingService $listing)
    {
    }

    public function resolveProducts(HomepageSection $section): EloquentCollection
    {
        $config = $section->config ?? [];
        $limit = (int) ($config['limit'] ?? 8);
        $query = Product::published()->with(['translations', 'variants', 'media']);

        return match ($config['data_source'] ?? null) {
            'featured' => $query->where('is_featured', true)->orderByDesc('published_at')->limit($limit)->get(),
            'latest' => $query->orderByDesc('published_at')->limit($limit)->get(),
            'best_selling' => $this->listing->bestSelling($limit),
            'category' => $query->where('category_id', $config['category_id'] ?? 0)->limit($limit)->get(),
            'collection' => Collection::query()->find($config['collection_id'] ?? 0)?->products()->published()->limit($limit)->get() ?? collect(),
            'tag' => $query->whereHas('tags', fn ($q) => $q->where('tags.id', $config['tag_id'] ?? 0))->limit($limit)->get(),
            default => $query->where('is_featured', true)->limit($limit)->get(),
        };
    }
}